from django.shortcuts import render
from django.core.mail import send_mail
from django.conf import settings

def home(request):
    return render(request, 'home.html')

def send_email(request):
    send_mail(
        'Welcome Party - reg.',
        'Greetings!!! Welcome to the Department of Information Technology.',
        settings.EMAIL_HOST_USER,
        ['kensindton123@gmail.com'],
        fail_silently=False,
    )
    return render(request, 'sendMail.html')
